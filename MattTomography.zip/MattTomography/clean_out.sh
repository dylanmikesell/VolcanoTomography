#! /bin/sh

# delete all files that get regenerated
rm -f pronto*.run
rm -f data*.obs
rm -f ray*.final
rm -f vel*.final


